DROP DATABASE IF EXISTS HuellasDB;
CREATE DATABASE HuellasDB;
USE HuellasDB;

CREATE TABLE Animales (
    id_animal INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    especie VARCHAR(30) NOT NULL,
    edad INT NOT NULL,
    estado VARCHAR(20) NOT NULL
);

CREATE TABLE Adoptantes (
    id_adoptante INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    ciudad VARCHAR(60) NOT NULL
);

CREATE TABLE Adopciones (
    id_adopcion INT AUTO_INCREMENT PRIMARY KEY,
    id_animal INT NOT NULL,
    id_adoptante INT NOT NULL,
    fecha_adopcion DATE NOT NULL,
    FOREIGN KEY (id_animal) REFERENCES Animales(id_animal),
    FOREIGN KEY (id_adoptante) REFERENCES Adoptantes(id_adoptante),
    UNIQUE (id_animal)
);

INSERT INTO Animales (nombre, especie, edad, estado)
VALUES
('Luna', 'Perro', 3, 'Adoptado'),
('Milo', 'Gato', 2, 'Adoptado'),
('Rocky', 'Perro', 5, 'Adoptado'),
('Nala', 'Gato', 1, 'Adoptado'),
('Toby', 'Conejo', 2, 'Adoptado'),
('Kiara', 'Perro', 4, 'Disponible'),
('Simba', 'Gato', 3, 'Disponible'),
('Copito', 'Conejo', 1, 'Disponible');

INSERT INTO Adoptantes (nombre, ciudad)
VALUES
('Ana Torres', 'Medellin'),
('Carlos Ruiz', 'Envigado'),
('Laura Gomez', 'Bello'),
('Andres Perez', 'Itagui'),
('Diana Lopez', 'Sabaneta');

INSERT INTO Adopciones (id_animal, id_adoptante, fecha_adopcion)
VALUES
(1, 1, '2026-01-10'),
(2, 2, '2026-01-15'),
(3, 3, '2026-02-05'),
(4, 4, '2026-02-20'),
(5, 5, '2026-03-01');

SELECT a.nombre AS animal, a.especie, p.nombre AS adoptante, p.ciudad, d.fecha_adopcion
FROM Adopciones d
JOIN Animales a ON a.id_animal = d.id_animal
JOIN Adoptantes p ON p.id_adoptante = d.id_adoptante;