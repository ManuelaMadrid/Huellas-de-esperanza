import mysql.connector
import pandas as pd
import matplotlib.pyplot as plt

conexion = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",          
    database="HuellasDB"
)
print("Conexión exitosa a HuellasDB")

cursor = conexion.cursor()

cursor.execute("SELECT * FROM Animales")
df = pd.DataFrame(cursor.fetchall(), columns=cursor.column_names)

cursor.execute("SELECT * FROM Adopciones")
df_adopciones = pd.DataFrame(cursor.fetchall(), columns=cursor.column_names)

cursor.close()
conexion.close()

print("\n=== Animales registrados ===")
print(df)

print("\n=== Cantidad de animales por especie ===")
conteo = df["especie"].value_counts()
print(conteo)

print("\n=== Edad promedio de los animales ===")
edad_promedio = df["edad"].mean()
print(f"{edad_promedio:.2f} años")

print("\n=== Total de adopciones realizadas ===")
total_adopciones = len(df_adopciones)
print(total_adopciones)

plt.bar(conteo.index, conteo.values, color=["#4C72B0", "#DD8452", "#55A868"])
plt.title("Cantidad de animales por especie - Huellas de Esperanza")
plt.xlabel("Especie")
plt.ylabel("Cantidad de animales")

for i, valor in enumerate(conteo.values):
    plt.text(i, valor + 0.05, str(valor), ha="center")

plt.savefig("grafica_especies.png")
plt.show()